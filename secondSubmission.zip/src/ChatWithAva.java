import java.util.*;
public class ChatWithAva implements Level {
    public ChatWithAva() {
    }
    
    @Override
    public String enter(Player p) throws InterruptedException{
        String nextLevelName = "";
        
        
        return nextLevelName;
    }
    
    
    @Override
    public String getName() {
        return "ChatWithAva";
    }
    
    
    //@Override public
}