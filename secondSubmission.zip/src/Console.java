import java.util.*;

public class Console implements Level {
    public String getName() {
        return "Console";
    }
    
    public String enter(Player p) throws InterruptedException{
        String nextLevelName = "";
        
        return nextLevelName;
    }
    
    
    
    
}